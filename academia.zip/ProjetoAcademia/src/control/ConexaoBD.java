/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author administrator
 */
public class ConexaoBD {
    public Statement stm;
    public ResultSet rs;
    private String driver = "com.mysql.jbdc.Driver";
    private String caminho = "jdbc:mysql://localhost/academia";
    private String usuario = "root";
    private String senha = "";
    public Connection con;
    
    public void conexao(){ //metodo responsavel por realizar a conexao com a base de dados
        try {
            System.setProperty("jdbc.Drivers", driver);
            con = DriverManager.getConnection(caminho, usuario, senha);
            //JOptionPane.showMessageDialog(null,"Conexao feita com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro de conexão com banco de dados: \n"+ex.getMessage());
        }
    }
    
    public void executaSql(String sql) {
        try {
            stm = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro no metodo executaSql! \n"+ex.getMessage());
        }
        
    }
    
    public void desconecta(){ //metodo responsavel por desconectar-se da base de dados
        try {
            con.close();
            JOptionPane.showMessageDialog(null,"BD Desconectado com sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao se desconectar do BD: \n"+ ex.getMessage());
        }
    }
            
}
